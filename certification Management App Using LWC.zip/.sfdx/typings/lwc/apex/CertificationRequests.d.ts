declare module "@salesforce/apex/CertificationRequests.getAllRequests" {
  export default function getAllRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getAllEmployees" {
  export default function getAllEmployees(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.deleteEmployees" {
  export default function deleteEmployees(param: {i: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.UpdateEmployee" {
  export default function UpdateEmployee(param: {EmpNamee: any, EmpIde: any, EmpMaile: any, EmpPSe: any, EmpSSe: any, EmpExpe: any, EmpComme: any, inde: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getAllCertifications" {
  export default function getAllCertifications(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.deleteCertifications" {
  export default function deleteCertifications(param: {i: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.updcertificate" {
  export default function updcertificate(param: {CertNamec: any, CertIdc: any, CertCostc: any, CertCommc: any, inde: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getAllVouchers" {
  export default function getAllVouchers(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.deleteVouchers" {
  export default function deleteVouchers(param: {i: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getDraftRequests" {
  export default function getDraftRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.deleteDraftRequests" {
  export default function deleteDraftRequests(param: {i: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getAssignedRequests" {
  export default function getAssignedRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getApprovedRequests" {
  export default function getApprovedRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getSubmittedRequests" {
  export default function getSubmittedRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getRejectedRequests" {
  export default function getRejectedRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getResultRequests" {
  export default function getResultRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getPassedRequests" {
  export default function getPassedRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.getFailedRequests" {
  export default function getFailedRequests(): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.addNewEmp" {
  export default function addNewEmp(param: {EmpName: any, EmpId: any, EmpMail: any, EmpPS: any, EmpSS: any, EmpExp: any, EmpComm: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.addNewCert" {
  export default function addNewCert(param: {CertName: any, CertId: any, CertCost: any, CertComm: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.addNewVou" {
  export default function addNewVou(param: {VouId: any, VouCost: any, VouValid: any, VouCert: any, VouComm: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.addNewReq" {
  export default function addNewReq(param: {ReqEmp: any, ReqCert: any, ReqDueDate: any, ReqComm: any, ReqEmpEmail: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.Updatedraftrequest" {
  export default function Updatedraftrequest(param: {ReqEmp: any, ReqCert: any, ReqDueDate: any, ReqEmpEmail: any, inde: any}): Promise<any>;
}
declare module "@salesforce/apex/CertificationRequests.updateRequest" {
  export default function updateRequest(param: {ReqRecordId: any, status: any}): Promise<any>;
}
