declare module "@salesforce/apex/CustomSearchController.searchRecords" {
  export default function searchRecords(param: {objName: any, fieldName: any, searchKey: any}): Promise<any>;
}
