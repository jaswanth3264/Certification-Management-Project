import { LightningElement,api, wire } from 'lwc';
import getdata from '@salesforce/apex/CertificationRequests.getDraftRequests';
import updateRequest from '@salesforce/apex/CertificationRequests.updateRequest';
import deldrarequest from '@salesforce/apex/CertificationRequests.deleteDraftRequests';
import upddrarequest from '@salesforce/apex/CertificationRequests.Updatedraftrequest'
export default class AppUserComponentTwo extends LightningElement {

    Requests;
    @wire (getdata)
    getApexData({error,data}){
        if(data){
            console.log(data);
            this.Requests=data;
            var req=data[0];
            console.log(req.Name);
        }
        if(error){
            console.log('error has occured');
        }
    }

    ind;
    val;
    eal;
    @api ReqName;
    ReqEmp;
    ReqCert;
    ReqDueDate;
    ReqComm;
    ReqEmpEmail;
    Remp;

    CertRecordId;
    EmpRecordId;
    edtdraempv;
    edtdracrev;
    edtdraduev;
    edtdraemmv;


    edreqflag=false;
    submitreq(event){
        this.ind=event.target.value;
        this.ReqRecordId = this.Requests[this.ind].Id;
    updateRequest({ReqRecordId:this.ReqRecordId,status:'Submitted'}).then(result=>{if(result=='Request Updated Successfully'){alert(result);window.location.reload();}else alert(result);});
    }
    delereq(event)
    {
        this.val=event.target.value;
        deldrarequest({i:this.val});
        location.reload();
        alert('Request has been scuessfully deleted');
    }
    RequestName(event){
        this.ReqName=event.target.value;
 }   
    
    ReqCommChange(event){
        this.ReqComm=event.target.value;
    }
    
    handleAutoSelect(event){
        var nav=event.detail;
   
        this.VouCert=nav.selectedRecordName;
        this.CertRecordId=nav.selectedRecordId;
       
    }
    handleAutoSelect1(event){
        var emp = event.detail;
        this.ReqEmp=emp.selectedRecordName;
        this.EmpRecordId=emp.selectedRecordId;
       
    }

    edtdraemp(event){
        this.edtdraempv=event.target.value;
    }
    edtdracre(event){
        this.edtdracrev=event.target.value;
    }
    ReqDueDateChange(event){
        this.ReqDueDate=event.target.value;
    }
    ReqEmployeeEmail(event){
        this.ReqEmpEmail=event.target.value;

    }
    
    editdrareq(event){
        this.edreqflag=true;
        this.eal=event.target.value;
        this.ReqName=this.Requests[this.eal].Name;
       // this.Remp=this.Requests[this.eal].Employee__r.Name;
    //    this.CertRecordId=this.Requests[this.eal].Certification__r.Name;
        this.ReqDueDate=this.Requests[this.eal].Due_Date__c;
        this.ReqEmpEmail=this.Requests[this.eal].Employee_Email__c;
        this.ReqComm=this.Requests[this.eal].Comments__c;   
       // alert('test for editing records' + this.eal);
    }
    upreq(event){
        alert(this.edtdraempv);
        alert(this.edtdracrev);
        alert(this.ReqDueDate);
        alert(this.ReqEmpEmail);
        upddrarequest({ReqEmp: this.edtdraempv, ReqCert: this.edtdracrev, ReqDueDate: this.ReqDueDate, ReqEmpEmail: this.ReqEmpEmail, inde:this.Requests[this.eal].Id});
        alert('request has been successfully edited');
        location.reload();

    }

    closepopup(){
        this.edreqflag=false;
    }
    handleSubmit(event) {
        console.log('onsubmit: '+ event.detail.fields);
 
    }
    handleSuccess(event) {
        const updatedRecord = event.detail.id;
        console.log('onsuccess: ', updatedRecord);
    }
    




}