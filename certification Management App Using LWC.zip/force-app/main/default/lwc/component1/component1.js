import { LightningElement } from 'lwc';

export default class Component1 extends LightningElement {}