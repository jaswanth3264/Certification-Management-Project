import { LightningElement, wire } from 'lwc';
import addrequest from '@salesforce/apex/CertificationRequests.addNewReq';
import viewemployees from '@salesforce/apex/CertificationRequests.getAllEmployees';
import viewcertifications from '@salesforce/apex/CertificationRequests.getAllCertifications';
import viewvouchers from '@salesforce/apex/CertificationRequests.getAllVouchers';
export default class AppUserComponentOne extends LightningElement {
    reqflag;
    
    ReqName;
    ReqEmp;
    ReqCert;
    ReqDueDate;
    ReqComm;
    ReqEmpEmail;

    CertRecordId;
    EmpRecordId;

    Employees;
    Certifications;
    Vouchers;


    viewempflag=false;
    viewcertflag=false;
    viewvouflag=false;

    viewemp(event){
        this.viewempflag=true;
    }
    viewcert(event){
        this.viewcertflag=true;
    }
    viewvouc(event){
        this.viewvouflag=true;
    }
    

    RequestName(event){
        this.ReqName=event.target.value;
    }   
    ReqDueDateChange(event){
        this.ReqDueDate=event.target.value;
    }
    ReqCommChange(event){
        this.ReqComm=event.target.value;
    }
    ReqEmployeeEmail(event){
        this.ReqEmpEmail=event.target.value;

    }
    handleAutoSelect(event){
        var nav=event.detail;
   
        this.VouCert=nav.selectedRecordName;
        this.CertRecordId=nav.selectedRecordId;
       
    }
    handleAutoSelect1(event){
        var emp = event.detail;
        this.ReqEmp=emp.selectedRecordName;
        this.EmpRecordId=emp.selectedRecordId;
       
    }

    reqform(){
        this.reqflag=true;
    }
    addreq(){
      // alert(this.ReqName);
         addrequest({ ReqEmp:this.EmpRecordId, ReqCert:this.CertRecordId, ReqDueDate:this.ReqDueDate, ReqComm:this.ReqComm, ReqEmpEmail:this.ReqEmpEmail}).then(result=>{if(result=='Request Added Successfully'){alert(result);window.location.reload();}else alert(result);});
    }
    //ReqNmae:this.ReqName,String ReqName,Name=ReqName,

    @wire (viewemployees)
    getApexData({error,data}){
        if(data){
            console.log(data);
            this.Employees=data;
            var req=data[0];
            console.log(req.Name);
        }
        if(error){
            console.log('error has occured');
        }
    }

    @wire (viewcertifications)
    getApexData1({error,data}){
        if(data){
            console.log(data);
            this.Certifications=data;
            var req=data[0];
            console.log(req.Name);
        }
        if(error){
            console.log('error has occured');
        }
    }

    @wire (viewvouchers)
    getApexData2({error,data}){
        if(data){
            console.log(data);
            this.Vouchers=data;
            var req=data[0];
            console.log(req.Name);
        }
        if(error){
            console.log('error has occured');
        }
    }

    closepopup(){
        this.reqflag=false;
        this.viewempflag=false;
        this.viewcertflag=false;
        this.viewvouflag=false;
    }



}