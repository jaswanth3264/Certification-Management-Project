import { LightningElement, wire } from 'lwc';
import addemployee from '@salesforce/apex/CertificationRequests.addNewEmp';
import addcertification from '@salesforce/apex/CertificationRequests.addNewCert';
import addvoucher from '@salesforce/apex/CertificationRequests.addNewVou';
import viewemployees from '@salesforce/apex/CertificationRequests.getAllEmployees';
import viewcertifications from '@salesforce/apex/CertificationRequests.getAllCertifications';
import viewvouchers from '@salesforce/apex/CertificationRequests.getAllVouchers';
import deleteemps from '@salesforce/apex/CertificationRequests.deleteEmployees';
import deletecerts from '@salesforce/apex/CertificationRequests.deleteCertifications';
import deletevous from '@salesforce/apex/CertificationRequests.deleteVouchers';
import updaemp from '@salesforce/apex/CertificationRequests.UpdateEmployee';
import upcerti from '@salesforce/apex/CertificationRequests.updcertificate';


export default class AdminComponentOne extends LightningElement {
    empflag;
    certflag;
    vouflag;

    viewempflag;
    viewcertflag;
    viewvouflag;

    Employees;
    Certifications;
    Vouchers;

    @wire (viewemployees)
    getApexData({error,data}){
        if(data){
            console.log(data);
            this.Employees=data;
            var req=data[0];
            console.log(req.Name);
        }
        if(error){
            console.log('error has occured');
        }
    }

    @wire (viewcertifications)
    getApexData1({error,data}){
        if(data){
            console.log(data);
            this.Certifications=data;
            var req=data[0];
            console.log(req.Name);
        }
        if(error){
            console.log('error has occured');
        }
    }

    @wire (viewvouchers)
    getApexData2({error,data}){
        if(data){
            console.log(data);
            this.Vouchers=data;
            var req=data[0];
            console.log(req.Name);
        }
        if(error){
            console.log('error has occured');
        }
    }

    viewemps() {
        this.viewempflag = true;
    }

    viewcerts() {
        this.viewcertflag = true;
    }
    viewvous() {
        this.viewvouflag = true;
    }

    EmpName;
    EmpId;
    EmpMail;
    EmpPS;
    EmpSS;
    EmpExp;
    EmpComm;

    CertName;
    CertId;
    CertCost;
    CertComm;

    VouId;
    VouCost;
    VouValid;
    VouCert;
    VouComm;

    CertRecordId;

    empid;
    certid;
    vouid;

    edtemp;
    edtcer;
    edtvou;

    // this variables for editing form
    employ;
    certifi;
    edtempflag=false;
    edtcertflag=false;

    EmpNamee;
    EmpIde;
    EmpMaile;
    EmpPSe;
    EmpSSe;
    EmpExpe;
    EmpComme;

    CertNamec;
    CertIdc;
    CertCostc;
    CertCommc;


    EmpNameChange(event) {
        this.EmpName = event.target.value;
    }
    EmpIdChange(event) {
        this.EmpId = event.target.value;
    }
    EmpMailChange(event) {
        this.EmpMail = event.target.value;
    }
    EmpPSChange(event) {
        this.EmpPS = event.target.value;
    }
    EmpSSChange(event) {
        this.EmpSS = event.target.value;
    }
    EmpExpChange(event) {
        this.EmpExp = event.target.value;
    }
    EmpCommChange(event) {
        this.EmpComm = event.target.value;
    }

    EmpNameChangee(event) {
        this.EmpNamee = event.target.value;
    }
    EmpIdChangee(event) {
        this.EmpIde = event.target.value;
    }
    EmpMailChangee(event) {
        this.EmpMaile = event.target.value;
    }
    EmpPSChangee(event) {
        this.EmpPSe = event.target.value;
    }
    EmpSSChangee(event) {
        this.EmpSSe = event.target.value;
    }
    EmpExpChangee(event) {
        this.EmpExpe = event.target.value;
    }
    EmpCommChangee(event) {
        this.EmpComme = event.target.value;
    }

    CertNameChange(event) {
        this.CertName = event.target.value;
    }
    CertIdChange(event) {
        this.CertId = event.target.value;
    }
    CertCostChange(event) {
        this.CertCost = event.target.value;
    }
    CertCommChange(event) {
        this.CertComm = event.target.value;
    }

    CertNameChangec(event) {
        this.CertNamec = event.target.value;
    }
    CertIdChangec(event) {
        this.CertIdc = event.target.value;
    }
    CertCostChangec(event) {
        this.CertCostc = event.target.value;
    }
    CertCommChangec(event) {
        this.CertCommc = event.target.value;
    }

    VouIdChange(event) {
        this.VouId = event.target.value;
    }
    VouCostChange(event) {
        this.VouCost = event.target.value;
    }
    VouValidChange(event) {
        this.VouValid = event.target.value;
        this.openlookup = true;
    }

    VouCommChange(event) {
        this.VouComm = event.target.value;
    }

    handleAutoSelect(event) {
        var nav = event.detail;

        this.VouCert = nav.selectedRecordName;
        this.CertRecordId = nav.selectedRecordId;
    }

    empform() {
        this.empflag = true;
    }

    certform() {
        this.certflag = true;
    }

    vouform() {
        this.vouflag = true;
    }


    addemp() {
        addemployee({ EmpName: this.EmpName, EmpId: this.EmpId, EmpMail: this.EmpMail, EmpPS: this.EmpPS, EmpSS: this.EmpSS, EmpExp: this.EmpExp, EmpComm: this.EmpComm }).then(result => { if (result == 'Employee Created Successfully') { alert(result); } else alert(result); });
        this.empflag = false;
        location.reload();
    }

    addcert() {
        addcertification({ CertName: this.CertName, CertId: this.CertId, CertCost: this.CertCost, CertComm: this.CertComm }).then(result => { if (result == 'Certification Created Successfully') { alert(result); } else alert(result); });
        this.certflag = false;
        location.reload();
    }

    addvou() {
        addvoucher({ VouId: this.VouId, VouCost: this.VouCost, VouValid: this.VouValid, VouCert: this.CertRecordId, VouComm: this.VouComm }).then(result => { if (result == 'Voucher Added Successfully') { alert(result); } else alert(result); });

        this.vouflag = false;
        location.reload();
    }

    closepopup() {
        this.empflag = false;
        this.certflag = false;
        this.vouflag = false;
        this.viewvouflag=false;
        this.viewempflag=false;
        this.viewcertflag=false;
        this.edtempflag=false;
        this.edtcertflag=false;
    }

    edtemprecord(event){
     this.employ=event.target.value;
     this.edtempflag=true;
     this.EmpNamee=this.Employees[this.employ].Name;
     this.EmpIde=this.Employees[this.employ].Employeeid__c;
     this.EmpMaile=this.Employees[this.employ].Employee_Email__c;
     this.EmpPSe=this.Employees[this.employ].Primary_Skill__c;
     this.EmpSSe=this.Employees[this.employ].SecondarySkill__c;
     this.EmpExpe=this.Employees[this.employ].Experience__c;
     this.EmpComme=this.Employees[this.employ].Comments__c;
        //alert('hi jaswanth' + this.employ);
        
    }

    updateemploy(){

        updaemp({ EmpNamee: this.EmpNamee, EmpIde: this.EmpIde, EmpMaile: this.EmpMaile, EmpPSe: this.EmpPSe, EmpSSe: this.EmpSSe, EmpExpe: this.EmpExpe, EmpComme: this.EmpComme, inde: this.Employees[this.employ].Id });
        location.reload();
        alert('Employee Record has been edited');

    }
    edtcertirecord(event){
        this.certifi=event.target.value;
        this.edtcertflag=true;
        this.CertNamec=this.Certifications[this.certifi].Name;                
        this.CertIdc=this.Certifications[this.certifi].Certification_Id__c;
        this.CertCostc=this.Certifications[this.certifi].Certification_Cost__c;
        this.CertCommc=this.Certifications[this.certifi].Comments__c;

       // alert('hi jaswanth' + this.certifi);
    }
    updatecertificate(){
        
        upcerti({ CertNamec: this.CertNamec, CertIdc: this.CertIdc, CertCostc: this.CertCostc, CertCommc: this.CertCommc, inde: this.Certifications[this.certifi].Id});
        location.reload();
    }
    

    deleteemp(event){
        this.empid=event.target.value;
        deleteemps({i:this.empid});
        this.viewempflag=false;
        location.reload();
    }

    deletecert(event){
        this.certid=event.target.value;
        deletecerts({i:this.certid});
        this.viewcertflag=false;
        location.reload();
    } 
    deletevou(event){
        this.vouid=event.target.value;
        deletevous({i:this.vouid});
        this.viewvouflag=false;
        location.reload();
    }

    


}